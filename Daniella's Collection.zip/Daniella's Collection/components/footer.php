<?php // components/footer.php ?>
</main>

<!-- ── Footer ─────────────────────────────────────────── -->
<footer class="bg-stone-800 text-stone-300 mt-20">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 grid grid-cols-1 md:grid-cols-3 gap-10">

    <!-- Brand -->
    <div>
      <h3 class="text-white text-lg font-bold mb-3">Daniella's Collection</h3>
      <p class="text-sm leading-relaxed text-stone-400">
        Premium boutique clothing &amp; accessories curated for the modern woman.
        Crafted with care, delivered with love.
      </p>
    </div>

    <!-- Links -->
    <div>
      <h4 class="text-white font-semibold mb-3 text-sm uppercase tracking-wider">Shop</h4>
      <ul class="space-y-2 text-sm">
        <li><a href="/" class="hover:text-white transition">Home</a></li>
        <li><a href="/catalog.php" class="hover:text-white transition">All Products</a></li>
        <li><a href="/catalog.php?category_id=1" class="hover:text-white transition">Dresses</a></li>
        <li><a href="/catalog.php?category_id=4" class="hover:text-white transition">Accessories</a></li>
      </ul>
    </div>

    <!-- Contact -->
    <div>
      <h4 class="text-white font-semibold mb-3 text-sm uppercase tracking-wider">Contact</h4>
      <ul class="space-y-2 text-sm">
        <li>📧 hello@daniellascollection.com</li>
        <li>📞 +1 (555) 012-3456</li>
        <li>📍 Beverly Hills, CA</li>
      </ul>
    </div>
  </div>

  <div class="border-t border-stone-700 py-5 text-center text-xs text-stone-500">
    © <?= date('Y') ?> Daniella's Collection. All rights reserved.
  </div>
</footer>

<!-- ── Sticky Mobile Cart Bar ────────────────────────── -->
<?php if (cart_count() > 0): ?>
<div class="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-stone-100 px-4 py-3 flex items-center gap-3 shadow-lg">
  <a href="/cart.php" class="btn-primary flex-1 justify-center">
    🛍 View Cart (<?= cart_count() ?> item<?= cart_count() !== 1 ? 's' : '' ?>)
  </a>
</div>
<?php endif; ?>

<!-- ── Global JS ──────────────────────────────────────── -->
<script src="/assets/js/app.js"></script>
</body>
</html>
