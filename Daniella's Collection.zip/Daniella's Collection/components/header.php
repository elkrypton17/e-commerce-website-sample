<?php
// components/header.php
// Variables expected from including file:
//   $pageTitle (string, optional)
//   $metaDescription (string, optional)
if (!isset($pageTitle))       $pageTitle       = "Daniella's Collection – Premium Boutique";
if (!isset($metaDescription)) $metaDescription = "Shop Daniella's Collection for premium, curated fashion. Dresses, tops, accessories and more.";
$cartCount = cart_count();
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="<?= h($metaDescription) ?>" />
  <meta name="csrf-token" content="<?= csrf_token() ?>" />
  <title><?= h($pageTitle) ?></title>

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: { sans: ['Inter', 'sans-serif'] },
          colors: {
            rose:  { DEFAULT:'#c2847a', light:'#ebd5d1', dark:'#a0665d' },
            stone: { 50:'#faf9f7', 100:'#f2ede8', 200:'#e5ddd5', 300:'#d4c8be', 400:'#b8a99a', 500:'#9c8878', 600:'#7a6b5e', 700:'#5e5248', 800:'#3e3530', 900:'#1e1a17' },
          },
          boxShadow: {
            'card': '0 4px 24px 0 rgba(60,40,20,0.08)',
            'card-hover': '0 8px 36px 0 rgba(60,40,20,0.14)',
          },
        }
      }
    }
  </script>

  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />

  <style>
    *, *::before, *::after { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body { font-family: 'Inter', sans-serif; background: #faf9f7; color: #3e3530; }
    .nav-link { position: relative; }
    .nav-link::after { content:''; position:absolute; bottom:-3px; left:0; width:0; height:2px; background:#c2847a; transition:width .25s ease; }
    .nav-link:hover::after, .nav-link.active::after { width:100%; }
    .btn-primary { background:#c2847a; color:#fff; border-radius:0.75rem; padding:.6rem 1.4rem; font-weight:600; font-size:.95rem; transition:background .2s, transform .1s; display:inline-flex; align-items:center; gap:.4rem; }
    .btn-primary:hover { background:#a0665d; transform:translateY(-1px); }
    .btn-primary:active { transform:translateY(0); }
    .btn-ghost { background:transparent; color:#c2847a; border:1.5px solid #c2847a; border-radius:0.75rem; padding:.55rem 1.3rem; font-weight:600; font-size:.95rem; transition:all .2s; }
    .btn-ghost:hover { background:#c2847a; color:#fff; }
    .card { background:#fff; border-radius:1.25rem; box-shadow:0 4px 24px 0 rgba(60,40,20,0.08); overflow:hidden; transition:box-shadow .25s, transform .25s; }
    .card:hover { box-shadow:0 8px 36px 0 rgba(60,40,20,0.14); transform:translateY(-3px); }
    .badge { display:inline-flex; align-items:center; border-radius:.5rem; padding:.2rem .65rem; font-size:.75rem; font-weight:600; }
    .badge-rose { background:#ebd5d1; color:#a0665d; }
    .badge-green { background:#d1fae5; color:#065f46; }
    .badge-red   { background:#fee2e2; color:#991b1b; }
    .badge-yellow{ background:#fef3c7; color:#92400e; }

    /* Toast */
    #toast { pointer-events:none; }
    #toast.show { pointer-events:auto; }

    /* Mobile overlay */
    #mobile-overlay { backdrop-filter:blur(6px); }

    /* Custom scrollbar */
    ::-webkit-scrollbar { width:6px; height:6px; }
    ::-webkit-scrollbar-track { background:#f2ede8; }
    ::-webkit-scrollbar-thumb { background:#d4c8be; border-radius:3px; }

    /* Cart badge bounce */
    @keyframes bump { 0%,100%{transform:scale(1)} 50%{transform:scale(1.4)} }
    .cart-bump { animation:bump .3s ease; }

    /* Fade-in */
    @keyframes fadeIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:none} }
    .fade-in { animation:fadeIn .45s ease both; }
  </style>
</head>
<body>

<!-- ── Toast ─────────────────────────────────────────── -->
<div id="toast" role="status" aria-live="polite"
     class="fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-xl shadow-lg
            text-white text-sm font-medium flex items-center gap-2
            transition-all duration-300 opacity-0 pointer-events-none translate-y-4">
  <span id="toast-icon"></span>
  <span id="toast-msg"></span>
</div>

<!-- ── Mobile Overlay ────────────────────────────────── -->
<div id="mobile-overlay"
     class="fixed inset-0 bg-stone-900/40 z-40 hidden transition-opacity duration-300 opacity-0"
     onclick="closeMobileMenu()"></div>

<!-- ── Mobile Drawer ──────────────────────────────────── -->
<aside id="mobile-drawer"
       class="fixed top-0 right-0 h-full w-72 bg-white z-50 shadow-2xl transform translate-x-full transition-transform duration-300 flex flex-col">
  <div class="flex items-center justify-between px-6 py-5 border-b border-stone-100">
    <span class="text-lg font-bold text-stone-800">Menu</span>
    <button onclick="closeMobileMenu()" class="text-stone-500 hover:text-stone-800" aria-label="Close">
      <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
    </button>
  </div>
  <nav class="flex-1 flex flex-col gap-1 px-4 py-6">
    <a href="/" class="px-4 py-3 rounded-xl text-stone-700 hover:bg-stone-100 font-medium transition">Home</a>
    <a href="/catalog.php" class="px-4 py-3 rounded-xl text-stone-700 hover:bg-stone-100 font-medium transition">Catalog</a>
    <a href="/cart.php" class="px-4 py-3 rounded-xl text-stone-700 hover:bg-stone-100 font-medium transition flex justify-between">
      Cart
      <span id="mob-cart-count" class="badge badge-rose"><?= $cartCount ?></span>
    </a>
  </nav>
  <div class="px-6 pb-8">
    <a href="/cart.php" class="btn-primary w-full justify-center">View Cart</a>
  </div>
</aside>

<!-- ── Top Announcement Bar ───────────────────────────── -->
<div class="bg-stone-800 text-stone-200 text-center text-xs py-2 tracking-wide">
  ✨ Free shipping on orders over $150 &nbsp;·&nbsp; Premium boutique since 2019
</div>

<!-- ── Main Header ────────────────────────────────────── -->
<header class="bg-white/90 backdrop-blur-md sticky top-0 z-30 border-b border-stone-100">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">

    <!-- Logo -->
    <a href="/" class="flex items-center gap-2 group">
      <svg class="w-7 h-7 text-rose" viewBox="0 0 32 32" fill="currentColor">
        <path d="M16 2C8.268 2 2 8.268 2 16s6.268 14 14 14 14-6.268 14-14S23.732 2 16 2zm0 4a10 10 0 0 1 8.48 15.32L8.68 7.52A9.96 9.96 0 0 1 16 6zm0 20a10 10 0 0 1-8.48-15.32l15.8 13.8A9.96 9.96 0 0 1 16 26z"/>
      </svg>
      <span class="text-xl font-bold text-stone-800 tracking-tight group-hover:text-rose transition">
        Daniella's
        <span class="text-rose font-light">Collection</span>
      </span>
    </a>

    <!-- Desktop Nav -->
    <nav class="hidden md:flex items-center gap-8">
      <a href="/"           class="nav-link text-stone-600 hover:text-stone-900 font-medium text-sm transition">Home</a>
      <a href="/catalog.php" class="nav-link text-stone-600 hover:text-stone-900 font-medium text-sm transition">Catalog</a>
    </nav>

    <!-- Right actions -->
    <div class="flex items-center gap-3">
      <a href="/cart.php" class="relative flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-stone-50 transition" aria-label="Cart">
        <svg class="w-5 h-5 text-stone-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4zM3 6h18M16 10a4 4 0 01-8 0"/>
        </svg>
        <span id="cart-count"
              class="inline-flex items-center justify-center w-5 h-5 text-xs font-bold bg-rose text-white rounded-full transition-transform">
          <?= $cartCount ?>
        </span>
      </a>
      <button onclick="openMobileMenu()" class="md:hidden p-2 rounded-xl hover:bg-stone-50 text-stone-700" aria-label="Open menu">
        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
      </button>
    </div>
  </div>
</header>

<!-- ── Flash message ──────────────────────────────────── -->
<?php if ($flash): ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
  <div class="rounded-xl px-4 py-3 text-sm font-medium flex items-center gap-2
    <?= $flash['type'] === 'success' ? 'bg-green-50 text-green-800 border border-green-200'
                                     : 'bg-red-50 text-red-800 border border-red-200' ?>">
    <?= $flash['type'] === 'success' ? '✓' : '✕' ?>
    <?= h($flash['message']) ?>
  </div>
</div>
<?php endif; ?>

<main class="min-h-[70vh]">
