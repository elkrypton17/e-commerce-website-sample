<?php
// components/product-card.php
// Required: $product array with keys: id, name, description, price, image_url, stock_quantity
// Optional: $product['category_name']
$inStock = ($product['stock_quantity'] ?? 0) > 0;
?>
<article class="card group flex flex-col h-full" data-product-id="<?= (int)$product['id'] ?>">

  <!-- Image -->
  <a href="/product.php?id=<?= (int)$product['id'] ?>" class="block overflow-hidden aspect-[3/4] bg-stone-100">
    <img
      src="<?= product_image($product['image_url'] ?? null) ?>"
      alt="<?= h($product['name']) ?>"
      class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
      loading="lazy"
    />
  </a>

  <!-- Body -->
  <div class="flex flex-col flex-1 p-4 gap-2">
    <?php if (!empty($product['category_name'])): ?>
      <span class="text-[10px] uppercase tracking-widest font-semibold text-stone-400">
        <?= h($product['category_name']) ?>
      </span>
    <?php endif; ?>

    <a href="/product.php?id=<?= (int)$product['id'] ?>"
       class="text-stone-800 font-semibold text-sm leading-snug hover:text-rose transition line-clamp-2">
      <?= h($product['name']) ?>
    </a>

    <p class="text-stone-400 text-xs leading-relaxed line-clamp-2 flex-1">
      <?= h($product['description']) ?>
    </p>

    <div class="flex items-center justify-between mt-2">
      <span class="text-rose font-bold text-base"><?= money($product['price']) ?></span>

      <?php if ($inStock): ?>
        <button
          data-product-id="<?= (int)$product['id'] ?>"
          class="add-to-cart text-xs btn-primary py-2 px-3">
          + Add
        </button>
      <?php else: ?>
        <span class="badge badge-red text-[11px]">Out of Stock</span>
      <?php endif; ?>
    </div>
  </div>
</article>
