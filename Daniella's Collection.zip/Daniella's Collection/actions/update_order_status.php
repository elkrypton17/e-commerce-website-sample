<?php
// actions/update_order_status.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/admin/orders/list.php');

$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    set_flash('error', 'Security token mismatch.');
    redirect('/admin/orders/list.php');
}

$orderId = filter_input(INPUT_POST, 'order_id', FILTER_VALIDATE_INT);
$status  = $_POST['status'] ?? '';
$valid   = ['pending', 'processing', 'shipped', 'delivered'];

if (!$orderId || !in_array($status, $valid, true)) {
    set_flash('error', 'Invalid input.');
    redirect('/admin/orders/list.php');
}

try {
    $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $orderId]);
    set_flash('success', 'Order #' . $orderId . ' status updated to ' . $status . '.');
} catch (PDOException $e) {
    error_log('Order status error: ' . $e->getMessage());
    set_flash('error', 'Database error.');
}
redirect('/admin/orders/list.php');
