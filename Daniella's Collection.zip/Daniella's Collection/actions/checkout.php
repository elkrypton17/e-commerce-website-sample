<?php
// actions/checkout.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/cart.php');

$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    set_flash('error', 'Invalid security token. Please try again.');
    redirect('/checkout.php');
}

$name  = trim($_POST['customer_name']  ?? '');
$email = trim($_POST['customer_email'] ?? '');
$phone = trim($_POST['customer_phone'] ?? '');

if ($name === '' || $email === '') {
    set_flash('error', 'Please fill in all required fields.');
    redirect('/checkout.php');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    set_flash('error', 'Please enter a valid email address.');
    redirect('/checkout.php');
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) redirect('/cart.php');

try {
    $pdo->beginTransaction();

    // Lock & fetch product rows
    $pids = array_keys($cart);
    $ph   = implode(',', array_fill(0, count($pids), '?'));
    $stmt = $pdo->prepare("SELECT id, price, stock_quantity FROM products WHERE id IN ($ph) FOR UPDATE");
    $stmt->execute($pids);
    $products = $stmt->fetchAll(PDO::FETCH_UNIQUE);

    $total = 0.0;
    foreach ($cart as $pid => $qty) {
        if (!isset($products[$pid])) {
            throw new RuntimeException("Product #{$pid} not found");
        }
        if ($products[$pid]['stock_quantity'] < $qty) {
            throw new RuntimeException("Insufficient stock for product #{$pid}");
        }
        $total += (float)$products[$pid]['price'] * $qty;
    }

    // Insert order
    $orderStmt = $pdo->prepare(
        'INSERT INTO orders (customer_name, customer_email, customer_phone, total_amount, status)
         VALUES (?, ?, ?, ?, ?)'
    );
    $orderStmt->execute([$name, $email, $phone ?: null, $total, 'pending']);
    $orderId = (int)$pdo->lastInsertId();

    // Insert items & decrement stock
    $itemStmt  = $pdo->prepare(
        'INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES (?,?,?,?)'
    );
    $stockStmt = $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?');

    foreach ($cart as $pid => $qty) {
        $itemStmt->execute([$orderId, $pid, $qty, $products[$pid]['price']]);
        $stockStmt->execute([$qty, $pid]);
    }

    $pdo->commit();

    unset($_SESSION['cart']);
    redirect('/checkout_success.php?order_id=' . $orderId);

} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('Checkout error: ' . $e->getMessage());
    set_flash('error', 'An error occurred during checkout. Please try again.');
    redirect('/checkout.php');
}
