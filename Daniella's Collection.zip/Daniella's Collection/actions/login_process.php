<?php
// actions/login_process.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/admin/login.php');

$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    set_flash('error', 'Security token mismatch. Please try again.');
    redirect('/admin/login.php');
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    set_flash('error', 'Please enter both username and password.');
    redirect('/admin/login.php');
}

$stmt = $pdo->prepare('SELECT id, password_hash FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password_hash'])) {
    session_regenerate_id(true);
    $_SESSION['admin_user_id'] = $user['id'];
    $_SESSION['admin_username'] = $username;
    redirect('/admin/dashboard.php');
} else {
    // Constant-time delay to mitigate brute-force timing attacks
    usleep(random_int(200_000, 400_000));
    set_flash('error', 'Invalid username or password.');
    redirect('/admin/login.php');
}
