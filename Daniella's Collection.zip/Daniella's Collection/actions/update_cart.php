<?php
// actions/update_cart.php — AJAX handler for qty changes / removals
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['error' => 'Method not allowed']));
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    http_response_code(403);
    exit(json_encode(['error' => 'Invalid CSRF token']));
}

$productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
$newQty    = filter_input(INPUT_POST, 'quantity',   FILTER_VALIDATE_INT);

if (!$productId) {
    http_response_code(400);
    exit(json_encode(['error' => 'Invalid product_id']));
}

if ($newQty === false || $newQty === null || $newQty <= 0) {
    // Remove item
    unset($_SESSION['cart'][$productId]);
    $cartCount = array_sum($_SESSION['cart'] ?? []);
    exit(json_encode(['removed' => true, 'cartCount' => $cartCount]));
}

// Verify stock
$stmt = $pdo->prepare('SELECT price, stock_quantity FROM products WHERE id = ?');
$stmt->execute([$productId]);
$product = $stmt->fetch();
if (!$product) {
    http_response_code(404);
    exit(json_encode(['error' => 'Product not found']));
}
if ($newQty > $product['stock_quantity']) {
    exit(json_encode(['error' => 'Exceeds available stock', 'cartCount' => array_sum($_SESSION['cart'] ?? [])]));
}

$_SESSION['cart'][$productId] = $newQty;

// Compute updated totals
$cart       = $_SESSION['cart'];
$cartCount  = array_sum($cart);
$lineTotal  = (float)$product['price'] * $newQty;

// Recalculate full subtotal
$pids       = array_keys($cart);
$ph         = implode(',', array_fill(0, count($pids), '?'));
$stmtAll    = $pdo->prepare("SELECT id, price FROM products WHERE id IN ($ph)");
$stmtAll->execute($pids);
$allProds   = $stmtAll->fetchAll(PDO::FETCH_UNIQUE);

$subtotal = 0.0;
foreach ($cart as $pid => $qty) {
    $subtotal += ($allProds[$pid]['price'] ?? 0) * $qty;
}
$shipping   = $subtotal >= 150 ? 0 : 9.99;
$grandTotal = $subtotal + $shipping;

exit(json_encode([
    'cartCount'  => $cartCount,
    'lineTotal'  => '$' . number_format($lineTotal, 2),
    'subtotal'   => '$' . number_format($subtotal, 2),
    'grandTotal' => '$' . number_format($grandTotal, 2),
]));
