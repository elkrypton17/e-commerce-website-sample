<?php
// actions/add_to_cart.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['error' => 'Method not allowed']));
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    http_response_code(403);
    exit(json_encode(['error' => 'Invalid CSRF token']));
}

$productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
$quantity  = filter_input(INPUT_POST, 'quantity',   FILTER_VALIDATE_INT) ?: 1;

if (!$productId || $quantity < 1) {
    http_response_code(400);
    exit(json_encode(['error' => 'Invalid input']));
}

// Verify product & stock
$stmt = $pdo->prepare('SELECT id, stock_quantity FROM products WHERE id = ?');
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    http_response_code(404);
    exit(json_encode(['error' => 'Product not found']));
}

$inCart = $_SESSION['cart'][$productId] ?? 0;
if (($inCart + $quantity) > $product['stock_quantity']) {
    http_response_code(400);
    exit(json_encode(['error' => 'Not enough stock available']));
}

$_SESSION['cart'][$productId] = $inCart + $quantity;
$cartCount = array_sum($_SESSION['cart']);

exit(json_encode(['cartCount' => $cartCount]));
