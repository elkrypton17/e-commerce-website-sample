<?php
// actions/product_save.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/admin/products/list.php');

$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    set_flash('error', 'Security token mismatch.');
    redirect('/admin/products/list.php');
}

$id          = isset($_POST['id']) && ctype_digit($_POST['id']) ? (int)$_POST['id'] : null;
$name        = trim($_POST['name']        ?? '');
$description = trim($_POST['description'] ?? '');
$price       = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
$stock       = filter_input(INPUT_POST, 'stock_quantity', FILTER_VALIDATE_INT);
$catId       = isset($_POST['category_id']) && ctype_digit($_POST['category_id']) ? (int)$_POST['category_id'] : null;
$featured    = isset($_POST['featured']) ? 1 : 0;

$back = '/admin/products/' . ($id ? 'edit.php?id=' . $id : 'create.php');

if ($name === '' || $description === '' || $price === false || $stock === false) {
    set_flash('error', 'All required fields must be filled in correctly.');
    redirect($back);
}
if ($price < 0 || $stock < 0) {
    set_flash('error', 'Price and stock must be non-negative.');
    redirect($back);
}

// ── Image Upload ────────────────────────────────────────────────────
$imageUrl = null;
if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        set_flash('error', 'Image upload failed (error code ' . $_FILES['image']['error'] . ').');
        redirect($back);
    }
    $allowed  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $mime     = mime_content_type($_FILES['image']['tmp_name']);
    if (!array_key_exists($mime, $allowed)) {
        set_flash('error', 'Only JPG, PNG or WEBP images are accepted.');
        redirect($back);
    }
    if ($_FILES['image']['size'] > 2_097_152) { // 2 MB
        set_flash('error', 'Image must be under 2 MB.');
        redirect($back);
    }
    $ext      = $allowed[$mime];
    $filename = uniqid('prod_', true) . '.' . $ext;
    $uploadDir = __DIR__ . '/../public/uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $filename)) {
        set_flash('error', 'Could not save the uploaded image.');
        redirect($back);
    }
    $imageUrl = '/uploads/' . $filename;
}

try {
    if ($id) {
        // Keep existing image if no new one provided
        if ($imageUrl !== null) {
            $sql = 'UPDATE products SET name=?, description=?, price=?, stock_quantity=?, category_id=?, featured=?, image_url=? WHERE id=?';
            $params = [$name, $description, $price, $stock, $catId, $featured, $imageUrl, $id];
        } else {
            $sql = 'UPDATE products SET name=?, description=?, price=?, stock_quantity=?, category_id=?, featured=? WHERE id=?';
            $params = [$name, $description, $price, $stock, $catId, $featured, $id];
        }
        $pdo->prepare($sql)->execute($params);
        set_flash('success', 'Product updated successfully.');
    } else {
        $pdo->prepare(
            'INSERT INTO products (name, description, price, stock_quantity, category_id, featured, image_url)
             VALUES (?,?,?,?,?,?,?)'
        )->execute([$name, $description, $price, $stock, $catId, $featured, $imageUrl]);
        set_flash('success', 'Product created successfully.');
    }
    redirect('/admin/products/list.php');
} catch (PDOException $e) {
    error_log('Product save error: ' . $e->getMessage());
    set_flash('error', 'Database error. Please try again.');
    redirect($back);
}
