<?php
// actions/product_delete.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/admin/products/list.php');

$csrf = $_POST['csrf_token'] ?? '';
if (!verify_csrf($csrf)) {
    set_flash('error', 'Security token mismatch.');
    redirect('/admin/products/list.php');
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    set_flash('error', 'Invalid product ID.');
    redirect('/admin/products/list.php');
}

try {
    // Fetch image URL to delete file
    $stmt = $pdo->prepare('SELECT image_url FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    if (!$product) {
        set_flash('error', 'Product not found.');
        redirect('/admin/products/list.php');
    }
    $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$id]);
    // Clean up image file
    if ($product['image_url']) {
        $filePath = __DIR__ . '/../public' . $product['image_url'];
        if (file_exists($filePath)) @unlink($filePath);
    }
    set_flash('success', 'Product deleted successfully.');
} catch (PDOException $e) {
    error_log('Delete error: ' . $e->getMessage());
    set_flash('error', 'Could not delete product. It may be referenced by existing orders.');
}
redirect('/admin/products/list.php');
