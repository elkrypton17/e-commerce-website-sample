// public/assets/js/app.js

/**
 * Mobile Drawer / Overlay
 */
function openMobileMenu() {
  const drawer  = document.getElementById('mobile-drawer');
  const overlay = document.getElementById('mobile-overlay');
  if (drawer && overlay) {
    overlay.classList.remove('hidden');
    // small delay to allow display block to apply before opacity transition
    setTimeout(() => {
      overlay.classList.remove('opacity-0');
      drawer.classList.remove('translate-x-full');
    }, 10);
  }
}

function closeMobileMenu() {
  const drawer  = document.getElementById('mobile-drawer');
  const overlay = document.getElementById('mobile-overlay');
  if (drawer && overlay) {
    drawer.classList.add('translate-x-full');
    overlay.classList.add('opacity-0');
    setTimeout(() => overlay.classList.add('hidden'), 300);
  }
}

/**
 * Toast Notifications
 */
let toastTimeout;
window.showToast = function(message, type = 'success', duration = 3500) {
  const toast = document.getElementById('toast');
  const msg   = document.getElementById('toast-msg');
  const icon  = document.getElementById('toast-icon');
  if (!toast || !msg || !icon) return;

  msg.textContent = message;
  toast.className = 'fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-xl shadow-lg text-white text-sm font-medium flex items-center gap-2 transition-all duration-300 pointer-events-auto';
  
  if (type === 'success') {
    toast.classList.add('bg-stone-800');
    icon.textContent = '✓';
  } else {
    toast.classList.add('bg-red-600');
    icon.textContent = '✕';
  }

  // Force reflow
  void toast.offsetWidth;
  
  // Show
  toast.classList.remove('opacity-0', 'translate-y-4');

  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.add('opacity-0', 'translate-y-4');
    toast.classList.remove('pointer-events-auto');
  }, duration);
};

/**
 * Update global cart count UI
 */
window.updateCartCount = function(count) {
  const badge = document.getElementById('cart-count');
  const mobBadge = document.getElementById('mob-cart-count');
  if (badge) {
    badge.textContent = count;
    // trigger bump animation
    badge.classList.remove('cart-bump');
    void badge.offsetWidth; // force reflow
    badge.classList.add('cart-bump');
  }
  if (mobBadge) {
    mobBadge.textContent = count;
  }
};

/**
 * Global Add to Cart via fetch
 */
document.addEventListener('DOMContentLoaded', () => {
  const addButtons = document.querySelectorAll('.add-to-cart');
  addButtons.forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const productId = btn.dataset.productId;
      const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
      
      const fd = new FormData();
      fd.append('product_id', productId);
      fd.append('quantity', 1);
      fd.append('csrf_token', csrf);

      try {
        const res = await fetch('/actions/add_to_cart.php', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.cartCount !== undefined) {
          window.updateCartCount(data.cartCount);
          window.showToast('Added to cart', 'success');
        } else {
          window.showToast(data.error || 'Failed to add', 'error');
        }
      } catch (err) {
        window.showToast('Network error', 'error');
      }
    });
  });
});
