<?php
// public/product.php — Product detail page
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

$id = isset($_GET['id']) && ctype_digit($_GET['id']) ? (int)$_GET['id'] : null;
if (!$id) redirect('/catalog.php');

$stmt = $pdo->prepare(
    'SELECT p.*, c.name AS category_name, c.slug AS category_slug
     FROM products p LEFT JOIN categories c ON p.category_id = c.id
     WHERE p.id = ?'
);
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) redirect('/catalog.php');

// Related products
$stmtRelated = $pdo->prepare(
    'SELECT p.*, c.name AS category_name FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     WHERE p.category_id = ? AND p.id != ?
     ORDER BY RAND() LIMIT 4'
);
$stmtRelated->execute([$product['category_id'], $product['id']]);
$related = $stmtRelated->fetchAll();

$inStock = (int)$product['stock_quantity'] > 0;
$pageTitle = h($product['name']) . ' – Daniella\'s Collection';
$metaDescription = mb_substr(strip_tags($product['description']), 0, 155);

require_once __DIR__ . '/../components/header.php';
?>

<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

  <!-- Breadcrumb -->
  <nav class="flex items-center gap-2 text-xs text-stone-400 mb-8" aria-label="Breadcrumb">
    <a href="/" class="hover:text-rose transition">Home</a>
    <span>/</span>
    <a href="/catalog.php" class="hover:text-rose transition">Catalog</a>
    <?php if ($product['category_name']): ?>
    <span>/</span>
    <a href="/catalog.php?category_id=<?= $product['category_id'] ?>" class="hover:text-rose transition"><?= h($product['category_name']) ?></a>
    <?php endif; ?>
    <span>/</span>
    <span class="text-stone-600 font-medium"><?= h($product['name']) ?></span>
  </nav>

  <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">

    <!-- Image -->
    <div class="rounded-2xl overflow-hidden bg-stone-100 aspect-[3/4] max-h-[600px]">
      <img src="<?= product_image($product['image_url'] ?? null) ?>"
           alt="<?= h($product['name']) ?>"
           class="w-full h-full object-cover"
           id="product-main-img" />
    </div>

    <!-- Details -->
    <div class="flex flex-col gap-4">
      <?php if ($product['category_name']): ?>
      <span class="text-xs uppercase tracking-widest font-semibold text-stone-400">
        <?= h($product['category_name']) ?>
      </span>
      <?php endif; ?>

      <h1 class="text-3xl font-bold text-stone-900 leading-tight"><?= h($product['name']) ?></h1>

      <div class="flex items-center gap-3">
        <span class="text-3xl font-bold text-rose"><?= money($product['price']) ?></span>
        <?php if ($inStock): ?>
          <span class="badge badge-green">In Stock (<?= (int)$product['stock_quantity'] ?>)</span>
        <?php else: ?>
          <span class="badge badge-red">Out of Stock</span>
        <?php endif; ?>
      </div>

      <p class="text-stone-500 leading-relaxed"><?= nl2br(h($product['description'])) ?></p>

      <!-- Quantity & Add to Cart -->
      <?php if ($inStock): ?>
      <form id="product-atc-form" class="flex items-center gap-3 mt-2">
        <input type="hidden" name="product_id" value="<?= $product['id'] ?>" />
        <div class="flex items-center border border-stone-200 rounded-xl overflow-hidden">
          <button type="button" id="qty-minus"
                  class="w-10 h-10 flex items-center justify-center text-stone-600 hover:bg-stone-50 transition text-lg">−</button>
          <input type="number" id="qty-input" name="quantity" value="1"
                 min="1" max="<?= (int)$product['stock_quantity'] ?>"
                 class="w-14 text-center border-none outline-none text-sm font-semibold text-stone-800 bg-transparent" />
          <button type="button" id="qty-plus"
                  class="w-10 h-10 flex items-center justify-center text-stone-600 hover:bg-stone-50 transition text-lg">+</button>
        </div>
        <button type="submit" class="btn-primary flex-1 justify-center py-3 text-base">
          🛍 Add to Cart
        </button>
      </form>
      <?php else: ?>
      <button disabled class="btn-primary opacity-50 cursor-not-allowed py-3 text-base">Out of Stock</button>
      <?php endif; ?>

      <!-- Perks -->
      <ul class="mt-4 space-y-2 text-sm text-stone-500">
        <li class="flex items-center gap-2">✅ Free shipping on orders over $150</li>
        <li class="flex items-center gap-2">✅ Easy 30-day returns</li>
        <li class="flex items-center gap-2">✅ Secure checkout</li>
      </ul>
    </div>
  </div>

  <!-- Related Products -->
  <?php if ($related): ?>
  <div class="mt-16">
    <h2 class="text-xl font-bold text-stone-800 mb-6">You May Also Like</h2>
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-6">
      <?php foreach ($related as $product): ?>
        <?php include __DIR__ . '/../components/product-card.php'; ?>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

</section>

<script>
// Qty controls
(function(){
  const qtyInput = document.getElementById('qty-input');
  if (!qtyInput) return;
  const max = parseInt(qtyInput.getAttribute('max'), 10);
  document.getElementById('qty-minus').addEventListener('click', () => {
    qtyInput.value = Math.max(1, parseInt(qtyInput.value,10) - 1);
  });
  document.getElementById('qty-plus').addEventListener('click', () => {
    qtyInput.value = Math.min(max, parseInt(qtyInput.value,10) + 1);
  });

  document.getElementById('product-atc-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('csrf_token', document.querySelector('meta[name="csrf-token"]').content);
    try {
      const res  = await fetch('/actions/add_to_cart.php', { method:'POST', body: fd });
      const data = await res.json();
      if (data.cartCount !== undefined) {
        window.updateCartCount(data.cartCount);
        window.showToast('Added to cart!', 'success');
      } else {
        window.showToast(data.error || 'Could not add to cart', 'error');
      }
    } catch { window.showToast('Network error', 'error'); }
  });
})();
</script>

<?php require_once __DIR__ . '/../components/footer.php'; ?>
