<?php
// public/checkout_success.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

$orderId = isset($_GET['order_id']) && ctype_digit($_GET['order_id']) ? (int)$_GET['order_id'] : null;
if (!$orderId) redirect('/');

$stmtO = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
$stmtO->execute([$orderId]);
$order = $stmtO->fetch();
if (!$order) redirect('/');

$stmtI = $pdo->prepare(
    'SELECT oi.*, p.name, p.image_url FROM order_items oi
     JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?'
);
$stmtI->execute([$orderId]);
$items = $stmtI->fetchAll();

$pageTitle       = "Order Confirmed – Daniella's Collection";
$metaDescription = "Your order has been placed successfully. Thank you for shopping with us!";
require_once __DIR__ . '/../components/header.php';
?>

<section class="max-w-2xl mx-auto px-4 sm:px-6 py-16 text-center">
  <div class="text-6xl mb-6">🎉</div>
  <h1 class="text-3xl font-bold text-stone-800 mb-2">Order Confirmed!</h1>
  <p class="text-stone-500 mb-8">
    Thank you, <strong><?= h($order['customer_name']) ?></strong>!
    Your order <strong>#<?= $order['id'] ?></strong> has been placed and is being prepared.
    A confirmation will be sent to <strong><?= h($order['customer_email']) ?></strong>.
  </p>

  <div class="card p-6 text-left mb-8">
    <h2 class="font-semibold text-stone-800 mb-4 text-base">Order Items</h2>
    <ul class="space-y-4">
      <?php foreach ($items as $item): ?>
      <li class="flex items-center gap-3">
        <img src="<?= product_image($item['image_url'] ?? null) ?>"
             class="w-14 h-14 rounded-xl object-cover shrink-0" alt="<?= h($item['name']) ?>" />
        <div class="flex-1">
          <div class="font-medium text-stone-800 text-sm"><?= h($item['name']) ?></div>
          <div class="text-stone-400 text-xs">Qty: <?= $item['quantity'] ?> × <?= money($item['price_at_purchase']) ?></div>
        </div>
        <span class="font-semibold text-rose text-sm"><?= money($item['price_at_purchase'] * $item['quantity']) ?></span>
      </li>
      <?php endforeach; ?>
    </ul>
    <div class="border-t border-stone-100 mt-4 pt-4 flex justify-between font-bold text-stone-800 text-base">
      <span>Total Paid</span>
      <span class="text-rose"><?= money($order['total_amount']) ?></span>
    </div>
  </div>

  <div class="flex flex-col sm:flex-row gap-3 justify-center">
    <a href="/" class="btn-primary px-8 py-3">Continue Shopping</a>
    <a href="/catalog.php" class="btn-ghost px-8 py-3">View Catalog</a>
  </div>
</section>

<?php require_once __DIR__ . '/../components/footer.php'; ?>
