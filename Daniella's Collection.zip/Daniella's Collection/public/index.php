<?php
// public/index.php — Homepage
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

$pageTitle = "Daniella's Collection – Premium Boutique Fashion";
$metaDescription = "Discover Daniella's Collection — curated premium clothing, dresses, tops and accessories. Shop the new arrivals today.";

// Featured products (featured flag = 1)
$stmtFeatured = $pdo->query(
    "SELECT p.*, c.name AS category_name FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     WHERE p.featured = 1 ORDER BY p.created_at DESC LIMIT 4"
);
$featured = $stmtFeatured->fetchAll();

// New Arrivals (latest 4, not already in featured)
$stmtNew = $pdo->query(
    "SELECT p.*, c.name AS category_name FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     WHERE p.stock_quantity > 0
     ORDER BY p.created_at DESC LIMIT 8"
);
$newArrivals = $stmtNew->fetchAll();

// Categories
$stmtCats = $pdo->query("SELECT * FROM categories ORDER BY name");
$categories = $stmtCats->fetchAll();

require_once __DIR__ . '/../components/header.php';
?>

<!-- ── Hero ─────────────────────────────────────────── -->
<section class="relative overflow-hidden bg-gradient-to-br from-stone-100 via-rose-50 to-stone-200 min-h-[70vh] flex items-center">
  <!-- Decorative circles -->
  <div class="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-rose/10 blur-3xl"></div>
  <div class="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-stone-300/30 blur-3xl"></div>

  <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
    <div class="fade-in">
      <span class="badge badge-rose mb-4">New Season 2026</span>
      <h1 class="text-5xl md:text-6xl font-bold text-stone-900 leading-tight mb-6">
        Dress for<br/>
        <span class="text-rose italic font-light">every moment</span>
      </h1>
      <p class="text-stone-500 text-lg mb-8 max-w-md leading-relaxed">
        Premium boutique fashion crafted for the modern woman. Discover timeless pieces that elevate your everyday.
      </p>
      <div class="flex flex-wrap gap-3">
        <a href="/catalog.php" class="btn-primary text-base px-7 py-3">Shop the Collection</a>
        <a href="/catalog.php?category_id=1" class="btn-ghost text-base px-7 py-3">View Dresses</a>
      </div>
    </div>

    <!-- Hero visual grid -->
    <div class="hidden md:grid grid-cols-2 gap-3 fade-in" style="animation-delay:.15s">
      <?php foreach (array_slice($featured, 0, 4) as $i => $hero): ?>
      <a href="/product.php?id=<?= $hero['id'] ?>"
         class="<?= $i === 0 ? 'row-span-2' : '' ?> block overflow-hidden rounded-2xl bg-stone-200 group
                <?= $i === 0 ? 'aspect-[3/4]' : 'aspect-square' ?>">
        <img src="<?= product_image($hero['image_url'] ?? null) ?>"
             alt="<?= h($hero['name']) ?>"
             class="w-full h-full object-cover transition duration-500 group-hover:scale-105" />
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── Value Props ─────────────────────────────────── -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
  <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
    <?php foreach ([
      ['🚚','Free Shipping','On orders over $150'],
      ['✨','Premium Quality','Carefully curated pieces'],
      ['🔄','Easy Returns','30-day hassle-free policy'],
      ['💳','Secure Checkout','Your data is always safe'],
    ] as [$icon,$title,$sub]): ?>
    <div class="text-center p-5 rounded-2xl bg-white shadow-sm">
      <div class="text-3xl mb-2"><?= $icon ?></div>
      <div class="font-semibold text-stone-800 text-sm"><?= $title ?></div>
      <div class="text-stone-400 text-xs mt-1"><?= $sub ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ── Categories ─────────────────────────────────── -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
  <h2 class="text-2xl font-bold text-stone-800 mb-6">Shop by Category</h2>
  <div class="flex flex-wrap gap-3">
    <a href="/catalog.php"
       class="px-5 py-2 rounded-full bg-rose text-white font-semibold text-sm hover:bg-rose-dark transition">
      All
    </a>
    <?php foreach ($categories as $cat): ?>
    <a href="/catalog.php?category_id=<?= $cat['id'] ?>"
       class="px-5 py-2 rounded-full bg-white border border-stone-200 text-stone-700 font-medium text-sm hover:border-rose hover:text-rose transition">
      <?= h($cat['name']) ?>
    </a>
    <?php endforeach; ?>
  </div>
</section>

<!-- ── Featured Products ───────────────────────────── -->
<?php if ($featured): ?>
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
  <div class="flex items-end justify-between mb-6">
    <div>
      <h2 class="text-2xl font-bold text-stone-800">Featured Pieces</h2>
      <p class="text-stone-400 text-sm mt-1">Hand-picked favourites from the collection</p>
    </div>
    <a href="/catalog.php" class="text-rose font-semibold text-sm hover:underline">View all →</a>
  </div>
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    <?php foreach ($featured as $product): ?>
      <?php include __DIR__ . '/../components/product-card.php'; ?>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- ── New Arrivals ────────────────────────────────── -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-20">
  <div class="flex items-end justify-between mb-6">
    <div>
      <h2 class="text-2xl font-bold text-stone-800">New Arrivals</h2>
      <p class="text-stone-400 text-sm mt-1">Just landed — be the first to shop</p>
    </div>
    <a href="/catalog.php" class="text-rose font-semibold text-sm hover:underline">View all →</a>
  </div>
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    <?php foreach ($newArrivals as $product): ?>
      <?php include __DIR__ . '/../components/product-card.php'; ?>
    <?php endforeach; ?>
  </div>
</section>

<?php require_once __DIR__ . '/../components/footer.php'; ?>
