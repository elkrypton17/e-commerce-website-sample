<?php
// public/catalog.php — Product catalog with filtering & sorting
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

// Fetch categories
$catStmt  = $pdo->query('SELECT * FROM categories ORDER BY name');
$categories = $catStmt->fetchAll();

// Filters
$catId    = isset($_GET['category_id']) && ctype_digit($_GET['category_id']) ? (int)$_GET['category_id'] : null;
$sort     = $_GET['sort'] ?? 'newest';
$search   = trim($_GET['q'] ?? '');

// Build query
$where    = [];
$params   = [];
if ($catId) {
    $where[]  = 'p.category_id = ?';
    $params[] = $catId;
}
if ($search !== '') {
    $where[]  = '(p.name LIKE ? OR p.description LIKE ?)';
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$orderBy = match($sort) {
    'price_asc'  => 'p.price ASC',
    'price_desc' => 'p.price DESC',
    'name_asc'   => 'p.name ASC',
    default      => 'p.created_at DESC',
};

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$sql = "SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        {$whereSql}
        ORDER BY {$orderBy}";

$stmt     = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$activeCat = $catId ? $pdo->prepare('SELECT name FROM categories WHERE id = ?') : null;
$catName   = '';
if ($catId) {
    $activeCat->execute([$catId]);
    $catName = $activeCat->fetchColumn() ?: '';
}

$pageTitle       = $catName ? h($catName) . ' – Daniella\'s Collection' : 'Shop All – Daniella\'s Collection';
$metaDescription = 'Browse our full catalog of premium boutique fashion. Filter by category and price.';

require_once __DIR__ . '/../components/header.php';
?>

<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

  <!-- Page heading -->
  <div class="mb-8">
    <h1 class="text-3xl font-bold text-stone-800">
      <?= $catName ? h($catName) : 'All Products' ?>
    </h1>
    <p class="text-stone-400 mt-1 text-sm"><?= count($products) ?> item<?= count($products) !== 1 ? 's' : '' ?> found</p>
  </div>

  <div class="flex flex-col lg:flex-row gap-8">

    <!-- ── Sidebar Filters ───────────────────────── -->
    <aside class="lg:w-60 shrink-0">
      <form id="filter-form" method="GET" class="space-y-6">

        <!-- Search -->
        <div>
          <label class="block text-xs uppercase tracking-wider text-stone-500 font-semibold mb-2">Search</label>
          <div class="relative">
            <input type="text" name="q" value="<?= h($search) ?>"
                   placeholder="Find products…"
                   class="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:border-rose focus:ring-1 focus:ring-rose transition" />
            <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          </div>
        </div>

        <!-- Categories -->
        <div>
          <label class="block text-xs uppercase tracking-wider text-stone-500 font-semibold mb-2">Category</label>
          <ul class="space-y-1">
            <li>
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="category_id" value="" <?= !$catId ? 'checked' : '' ?>
                       class="accent-rose" onchange="this.form.submit()" />
                <span class="text-sm text-stone-700">All Categories</span>
              </label>
            </li>
            <?php foreach ($categories as $cat): ?>
            <li>
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="category_id" value="<?= $cat['id'] ?>"
                       <?= $catId === (int)$cat['id'] ? 'checked' : '' ?>
                       class="accent-rose" onchange="this.form.submit()" />
                <span class="text-sm text-stone-700"><?= h($cat['name']) ?></span>
              </label>
            </li>
            <?php endforeach; ?>
          </ul>
        </div>

        <!-- Sort -->
        <div>
          <label class="block text-xs uppercase tracking-wider text-stone-500 font-semibold mb-2">Sort By</label>
          <select name="sort" onchange="this.form.submit()"
                  class="w-full rounded-xl border border-stone-200 text-sm py-2 px-3 focus:outline-none focus:border-rose focus:ring-1 focus:ring-rose transition">
            <option value="newest"     <?= $sort==='newest'     ? 'selected' : '' ?>>Newest First</option>
            <option value="price_asc"  <?= $sort==='price_asc'  ? 'selected' : '' ?>>Price: Low → High</option>
            <option value="price_desc" <?= $sort==='price_desc' ? 'selected' : '' ?>>Price: High → Low</option>
            <option value="name_asc"   <?= $sort==='name_asc'   ? 'selected' : '' ?>>Name A–Z</option>
          </select>
        </div>

        <?php if ($catId || $search || $sort !== 'newest'): ?>
        <a href="/catalog.php" class="block text-center text-rose text-sm font-medium hover:underline">Clear all filters</a>
        <?php endif; ?>
      </form>
    </aside>

    <!-- ── Product Grid ──────────────────────────── -->
    <div class="flex-1">
      <?php if (empty($products)): ?>
        <div class="text-center py-20 text-stone-400">
          <div class="text-5xl mb-4">🔍</div>
          <p class="text-lg font-medium">No products found</p>
          <a href="/catalog.php" class="mt-4 inline-block btn-primary">Clear Filters</a>
        </div>
      <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
          <?php foreach ($products as $product): ?>
            <?php include __DIR__ . '/../components/product-card.php'; ?>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

  </div>
</section>

<?php require_once __DIR__ . '/../components/footer.php'; ?>
