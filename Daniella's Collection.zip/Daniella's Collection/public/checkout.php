<?php
// public/checkout.php — Multi-step checkout
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) redirect('/cart.php');

// Build cart summary for preview
$pids  = array_keys($cart);
$ph    = implode(',', array_fill(0, count($pids), '?'));
$stmt  = $pdo->prepare("SELECT id, name, price, image_url FROM products WHERE id IN ($ph)");
$stmt->execute($pids);
$prods = $stmt->fetchAll(PDO::FETCH_UNIQUE);

$total = 0.0;
$items = [];
foreach ($cart as $pid => $qty) {
    if (!isset($prods[$pid])) continue;
    $lineTotal = (float)$prods[$pid]['price'] * $qty;
    $total += $lineTotal;
    $items[] = ['name' => $prods[$pid]['name'], 'qty' => $qty, 'line' => $lineTotal, 'img' => $prods[$pid]['image_url']];
}
$shipping   = $total >= 150 ? 0 : 9.99;
$grandTotal = $total + $shipping;

$pageTitle       = "Checkout – Daniella's Collection";
$metaDescription = "Complete your purchase securely.";

require_once __DIR__ . '/../components/header.php';
?>

<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
  <h1 class="text-3xl font-bold text-stone-800 mb-8">Checkout</h1>

  <div class="grid grid-cols-1 lg:grid-cols-5 gap-10">

    <!-- ── Form ─────────────────────────────── -->
    <form action="/actions/checkout.php" method="POST"
          class="lg:col-span-3 space-y-6" id="checkout-form">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>" />

      <!-- Contact Info -->
      <div class="card p-6">
        <h2 class="text-lg font-semibold text-stone-800 mb-4">Contact Information</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div class="sm:col-span-2">
            <label class="block text-xs uppercase tracking-wider text-stone-500 font-semibold mb-1">Full Name *</label>
            <input type="text" name="customer_name" required autocomplete="name"
                   placeholder="Jane Doe"
                   class="w-full rounded-xl border border-stone-200 px-4 py-2.5 text-sm focus:outline-none focus:border-rose focus:ring-1 focus:ring-rose transition" />
          </div>
          <div>
            <label class="block text-xs uppercase tracking-wider text-stone-500 font-semibold mb-1">Email Address *</label>
            <input type="email" name="customer_email" required autocomplete="email"
                   placeholder="jane@example.com"
                   class="w-full rounded-xl border border-stone-200 px-4 py-2.5 text-sm focus:outline-none focus:border-rose focus:ring-1 focus:ring-rose transition" />
          </div>
          <div>
            <label class="block text-xs uppercase tracking-wider text-stone-500 font-semibold mb-1">Phone Number</label>
            <input type="tel" name="customer_phone" autocomplete="tel"
                   placeholder="+1 (555) 000-0000"
                   class="w-full rounded-xl border border-stone-200 px-4 py-2.5 text-sm focus:outline-none focus:border-rose focus:ring-1 focus:ring-rose transition" />
          </div>
        </div>
      </div>

      <!-- Payment Placeholder -->
      <div class="card p-6">
        <h2 class="text-lg font-semibold text-stone-800 mb-1">Payment</h2>
        <p class="text-xs text-stone-400 mb-4">Payment gateway integration coming soon. Orders will be reviewed and invoiced manually.</p>
        <div class="rounded-xl border border-dashed border-stone-200 p-5 text-center text-stone-400 text-sm">
          💳 Secure payment gateway placeholder
        </div>
      </div>

      <button type="submit" class="btn-primary w-full justify-center py-4 text-base">
        Place Order – <?= money($grandTotal) ?>
      </button>

      <p class="text-xs text-stone-400 text-center">
        By placing your order you agree to our Terms of Service. Your data is protected.
      </p>
    </form>

    <!-- ── Order Summary Sidebar ─────────────────── -->
    <aside class="lg:col-span-2">
      <div class="card p-6 sticky top-24">
        <h2 class="text-base font-semibold text-stone-800 mb-4">Order Summary</h2>
        <ul class="space-y-3 mb-4">
          <?php foreach ($items as $item): ?>
          <li class="flex items-center gap-3">
            <img src="<?= product_image($item['img'] ?? null) ?>"
                 class="w-14 h-14 rounded-xl object-cover shrink-0" alt="<?= h($item['name']) ?>" />
            <div class="flex-1 text-sm">
              <div class="font-medium text-stone-800 line-clamp-1"><?= h($item['name']) ?></div>
              <div class="text-stone-400 text-xs">Qty: <?= $item['qty'] ?></div>
            </div>
            <span class="text-rose font-semibold text-sm shrink-0"><?= money($item['line']) ?></span>
          </li>
          <?php endforeach; ?>
        </ul>
        <div class="border-t border-stone-100 pt-4 space-y-2 text-sm">
          <div class="flex justify-between text-stone-500">
            <span>Subtotal</span><span><?= money($total) ?></span>
          </div>
          <div class="flex justify-between text-stone-500">
            <span>Shipping</span><span><?= $shipping === 0.0 ? 'Free' : money($shipping) ?></span>
          </div>
          <div class="flex justify-between font-bold text-stone-800 text-base border-t border-stone-100 pt-3 mt-1">
            <span>Total</span><span><?= money($grandTotal) ?></span>
          </div>
        </div>
      </div>
    </aside>

  </div>
</section>

<?php require_once __DIR__ . '/../components/footer.php'; ?>
