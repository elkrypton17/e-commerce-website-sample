<?php
// public/cart.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

$pageTitle = "Your Cart – Daniella's Collection";
$metaDescription = "Review your shopping cart and proceed to checkout.";

$cart  = $_SESSION['cart'] ?? [];
$items = [];
$total = 0.0;

if ($cart) {
    $pids         = array_keys($cart);
    $placeholders = implode(',', array_fill(0, count($pids), '?'));
    $stmt         = $pdo->prepare("SELECT id, name, price, image_url, stock_quantity FROM products WHERE id IN ($placeholders)");
    $stmt->execute($pids);
    $prods        = $stmt->fetchAll(PDO::FETCH_UNIQUE);

    foreach ($cart as $pid => $qty) {
        if (!isset($prods[$pid])) continue;
        $p          = $prods[$pid];
        $lineTotal  = (float)$p['price'] * $qty;
        $total     += $lineTotal;
        $items[]    = [
            'id'        => $pid,
            'name'      => $p['name'],
            'price'     => (float)$p['price'],
            'image_url' => $p['image_url'],
            'stock'     => (int)$p['stock_quantity'],
            'qty'       => $qty,
            'line_total'=> $lineTotal,
        ];
    }
}

$freeShippingThreshold = 150.0;
$shippingLeft = max(0, $freeShippingThreshold - $total);

require_once __DIR__ . '/../components/header.php';
?>

<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
  <h1 class="text-3xl font-bold text-stone-800 mb-8">Your Cart</h1>

  <?php if (empty($items)): ?>
  <div class="text-center py-24">
    <div class="text-6xl mb-5">🛍</div>
    <h2 class="text-xl font-semibold text-stone-700 mb-2">Your cart is empty</h2>
    <p class="text-stone-400 mb-6">Start adding some beautiful pieces!</p>
    <a href="/catalog.php" class="btn-primary text-base px-8 py-3">Browse Catalog</a>
  </div>

  <?php else: ?>
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">

    <!-- Cart Items -->
    <div class="lg:col-span-2 space-y-4" id="cart-items">
      <?php foreach ($items as $item): ?>
      <div class="card flex gap-4 p-4" data-cart-row="<?= $item['id'] ?>">
        <a href="/product.php?id=<?= $item['id'] ?>" class="shrink-0">
          <img src="<?= product_image($item['image_url']) ?>"
               alt="<?= h($item['name']) ?>"
               class="w-24 h-24 object-cover rounded-xl" />
        </a>
        <div class="flex-1 flex flex-col justify-between gap-2">
          <div>
            <a href="/product.php?id=<?= $item['id'] ?>"
               class="font-semibold text-stone-800 hover:text-rose transition line-clamp-1">
              <?= h($item['name']) ?>
            </a>
            <div class="text-stone-500 text-sm"><?= money($item['price']) ?> each</div>
          </div>
          <div class="flex items-center justify-between">
            <!-- Qty controls -->
            <div class="flex items-center border border-stone-200 rounded-xl overflow-hidden">
              <button onclick="updateQty(<?= $item['id'] ?>, -1)"
                      class="w-8 h-8 flex items-center justify-center text-stone-600 hover:bg-stone-50 transition">−</button>
              <span class="w-10 text-center text-sm font-semibold text-stone-800" id="qty-<?= $item['id'] ?>">
                <?= $item['qty'] ?>
              </span>
              <button onclick="updateQty(<?= $item['id'] ?>, 1)"
                      class="w-8 h-8 flex items-center justify-center text-stone-600 hover:bg-stone-50 transition">+</button>
            </div>
            <!-- Line total + remove -->
            <div class="flex items-center gap-4">
              <span class="font-bold text-rose" id="line-<?= $item['id'] ?>"><?= money($item['line_total']) ?></span>
              <button onclick="removeItem(<?= $item['id'] ?>)"
                      class="text-stone-300 hover:text-red-500 transition" aria-label="Remove">
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                  <path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Order Summary -->
    <div class="lg:col-span-1">
      <div class="card p-6 sticky top-24">
        <h2 class="text-lg font-bold text-stone-800 mb-4">Order Summary</h2>

        <!-- Free shipping progress -->
        <?php if ($shippingLeft > 0): ?>
        <div class="mb-4 p-3 bg-stone-50 rounded-xl text-xs text-stone-600">
          <div class="flex justify-between mb-1">
            <span>Add <?= money($shippingLeft) ?> more for free shipping</span>
            <span class="font-semibold"><?= money($freeShippingThreshold) ?></span>
          </div>
          <div class="h-2 bg-stone-200 rounded-full overflow-hidden">
            <div class="h-full bg-rose rounded-full transition-all"
                 style="width:<?= min(100, round($total / $freeShippingThreshold * 100)) ?>%"></div>
          </div>
        </div>
        <?php else: ?>
        <div class="mb-4 p-3 bg-green-50 rounded-xl text-xs text-green-700 font-medium">
          ✓ You qualify for free shipping!
        </div>
        <?php endif; ?>

        <div class="space-y-2 text-sm mb-4">
          <div class="flex justify-between text-stone-600">
            <span>Subtotal</span>
            <span id="summary-subtotal"><?= money($total) ?></span>
          </div>
          <div class="flex justify-between text-stone-600">
            <span>Shipping</span>
            <span><?= $total >= $freeShippingThreshold ? 'Free' : '$9.99' ?></span>
          </div>
          <div class="flex justify-between font-bold text-stone-800 text-base border-t border-stone-100 pt-3 mt-3">
            <span>Total</span>
            <span id="summary-total">
              <?= money($total >= $freeShippingThreshold ? $total : $total + 9.99) ?>
            </span>
          </div>
        </div>

        <a href="/checkout.php" class="btn-primary w-full justify-center py-3 text-base">
          Proceed to Checkout →
        </a>
        <a href="/catalog.php" class="block text-center text-stone-400 text-sm mt-3 hover:text-rose transition">
          Continue Shopping
        </a>
      </div>
    </div>

  </div>
  <?php endif; ?>
</section>

<script>
const CSRF = document.querySelector('meta[name="csrf-token"]').content;

async function updateQty(productId, delta) {
  const qtyEl    = document.getElementById('qty-' + productId);
  const newQty   = Math.max(0, parseInt(qtyEl.textContent, 10) + delta);
  const fd       = new FormData();
  fd.append('product_id', productId);
  fd.append('quantity', newQty);
  fd.append('csrf_token', CSRF);
  const res  = await fetch('/actions/update_cart.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.removed) {
    document.querySelector('[data-cart-row="' + productId + '"]').remove();
  } else if (data.cartCount !== undefined) {
    qtyEl.textContent = newQty;
    document.getElementById('line-' + productId).textContent = data.lineTotal;
    document.getElementById('summary-subtotal').textContent = data.subtotal;
    document.getElementById('summary-total').textContent = data.grandTotal;
    window.updateCartCount(data.cartCount);
  }
  if (data.error) window.showToast(data.error, 'error');
}

async function removeItem(productId) {
  await updateQty(productId, -999);
}
</script>

<?php require_once __DIR__ . '/../components/footer.php'; ?>
