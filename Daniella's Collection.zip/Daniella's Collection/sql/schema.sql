-- ============================================================
-- Daniella's Collection — Full Database Schema + Seed Data
-- ============================================================
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ─────────────────────────────────────────
-- USERS (admin accounts)
-- ─────────────────────────────────────────
CREATE TABLE users (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username     VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────
-- CATEGORIES
-- ─────────────────────────────────────────
CREATE TABLE categories (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL UNIQUE,
  slug       VARCHAR(100) NOT NULL UNIQUE,
  created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────
-- PRODUCTS
-- ─────────────────────────────────────────
CREATE TABLE products (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id    INT UNSIGNED NULL,
  name           VARCHAR(255) NOT NULL,
  description    TEXT         NOT NULL,
  price          DECIMAL(10,2) NOT NULL,
  stock_quantity INT          NOT NULL DEFAULT 0,
  image_url      VARCHAR(255) NULL,
  featured       TINYINT(1)   NOT NULL DEFAULT 0,
  created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────
-- ORDERS
-- ─────────────────────────────────────────
CREATE TABLE orders (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  customer_name  VARCHAR(255) NOT NULL,
  customer_email VARCHAR(255) NOT NULL,
  customer_phone VARCHAR(20)  NULL,
  total_amount   DECIMAL(10,2) NOT NULL,
  status         ENUM('pending','processing','shipped','delivered') DEFAULT 'pending',
  created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────
-- ORDER ITEMS
-- ─────────────────────────────────────────
CREATE TABLE order_items (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id          INT UNSIGNED NOT NULL,
  product_id        INT UNSIGNED NOT NULL,
  quantity          INT          NOT NULL,
  price_at_purchase DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────
-- SEED: Admin user  (password: admin123)
-- Generated with: password_hash('admin123', PASSWORD_DEFAULT)
-- ─────────────────────────────────────────
INSERT INTO users (username, password_hash) VALUES
('admin', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- ─────────────────────────────────────────
-- SEED: Categories
-- ─────────────────────────────────────────
INSERT INTO categories (name, slug) VALUES
('Dresses',    'dresses'),
('Tops',       'tops'),
('Bottoms',    'bottoms'),
('Accessories','accessories'),
('Outerwear',  'outerwear');

-- ─────────────────────────────────────────
-- SEED: Products
-- ─────────────────────────────────────────
INSERT INTO products (category_id, name, description, price, stock_quantity, image_url, featured) VALUES
(1, 'Silk Wrap Dress',        'Luxurious silk wrap dress in champagne. Flattering silhouette with an adjustable tie waist.',        189.00, 12, NULL, 1),
(1, 'Floral Midi Dress',      'Elegant floral midi dress with a sweetheart neckline and puff sleeves. Perfect for garden parties.',  149.00, 8,  NULL, 1),
(2, 'Cashmere Knit Top',      'Ultra-soft 100% cashmere ribbed knit top in dusty rose. A wardrobe staple.',                         95.00, 20, NULL, 1),
(2, 'Satin Cami Blouse',      'Delicate satin cami blouse with adjustable straps. Pairs effortlessly with tailored trousers.',      75.00, 15, NULL, 0),
(3, 'Wide-Leg Linen Trousers','Breathable wide-leg linen trousers with a high waist and front pleats. Summer-ready and chic.',     120.00, 18, NULL, 0),
(3, 'Pleated Midi Skirt',     'Flowing pleated midi skirt in soft blush. Elasticated waist for all-day comfort.',                   98.00, 10, NULL, 1),
(4, 'Pearl Drop Earrings',    'Hand-knotted freshwater pearl drop earrings set in 18k gold-plated sterling silver.',                65.00, 30, NULL, 0),
(4, 'Leather Belt',           'Genuine Italian leather belt with a brushed gold buckle. Available in camel and black.',             55.00, 25, NULL, 0),
(5, 'Bouclé Blazer',          'Chanel-inspired bouclé blazer in cream. Fringe trim detail and a perfectly tailored fit.',          275.00, 6,  NULL, 1),
(5, 'Trench Coat',            'Classic belted trench coat in warm sand. Water-resistant cotton blend, fully lined.',               320.00, 4,  NULL, 0);
