<?php
// admin/dashboard.php
declare(strict_types=1);
$pageTitle = 'Dashboard';
require_once __DIR__ . '/_layout.php';

// Stats
$totalProducts = $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$totalOrders   = $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$pendingOrders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetchColumn();
$totalRevenue  = $pdo->query('SELECT COALESCE(SUM(total_amount),0) FROM orders')->fetchColumn();

// Recent orders
$recentOrders  = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>

<!-- Stats Cards -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
  <?php
  $stats = [
    ['Total Products', $totalProducts, '👗', '#ebd5d1'],
    ['Total Orders',   $totalOrders,   '📦', '#dbeafe'],
    ['Pending Orders', $pendingOrders, '⏳', '#fef3c7'],
    ['Revenue',        '$' . number_format($totalRevenue, 2), '💰', '#d1fae5'],
  ];
  foreach ($stats as [$label, $value, $icon, $bg]): ?>
  <div class="bg-white rounded-2xl p-5 shadow-sm flex flex-col gap-2">
    <div class="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style="background:<?= $bg ?>">
      <?= $icon ?>
    </div>
    <div class="text-2xl font-bold text-stone-800"><?= h((string)$value) ?></div>
    <div class="text-xs text-stone-400 font-medium"><?= $label ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Quick Actions -->
<div class="flex flex-wrap gap-3 mb-8">
  <a href="/admin/products/create.php" class="btn btn-rose">+ Add Product</a>
  <a href="/admin/products/list.php"   class="btn btn-outline">Manage Products</a>
  <a href="/admin/orders/list.php"     class="btn btn-outline">View All Orders</a>
</div>

<!-- Recent Orders -->
<div class="bg-white rounded-2xl shadow-sm overflow-hidden">
  <div class="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
    <h2 class="font-semibold text-stone-800">Recent Orders</h2>
    <a href="/admin/orders/list.php" class="text-xs text-rose font-medium hover:underline">View all →</a>
  </div>
  <table class="min-w-full">
    <thead><tr>
      <th class="px-6 py-3 text-left">Order</th>
      <th class="px-6 py-3 text-left">Customer</th>
      <th class="px-6 py-3 text-left">Amount</th>
      <th class="px-6 py-3 text-left">Status</th>
      <th class="px-6 py-3 text-left">Date</th>
      <th class="px-6 py-3 text-left"></th>
    </tr></thead>
    <tbody class="divide-y divide-stone-50">
      <?php if (empty($recentOrders)): ?>
      <tr><td colspan="6" class="px-6 py-8 text-center text-stone-400">No orders yet.</td></tr>
      <?php else: foreach ($recentOrders as $order):
        $statusColors = ['pending'=>'badge bg-yellow-100 text-yellow-800','processing'=>'badge bg-blue-100 text-blue-800','shipped'=>'badge bg-purple-100 text-purple-800','delivered'=>'badge bg-green-100 text-green-800'];
        $sc = $statusColors[$order['status']] ?? 'badge bg-stone-100 text-stone-600';
      ?>
      <tr class="hover:bg-stone-50/50">
        <td class="px-6 py-3 font-mono text-stone-500 text-sm">#<?= $order['id'] ?></td>
        <td class="px-6 py-3 font-medium text-stone-800 text-sm"><?= h($order['customer_name']) ?></td>
        <td class="px-6 py-3 text-stone-700 text-sm font-semibold">$<?= number_format($order['total_amount'],2) ?></td>
        <td class="px-6 py-3"><span class="<?= $sc ?>"><?= ucfirst($order['status']) ?></span></td>
        <td class="px-6 py-3 text-stone-400 text-xs"><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
        <td class="px-6 py-3"><a href="/admin/orders/view.php?id=<?= $order['id'] ?>" class="text-xs font-medium text-rose hover:underline">View</a></td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_close.php'; ?>
