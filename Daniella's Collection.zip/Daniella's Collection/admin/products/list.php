<?php
// admin/products/list.php
declare(strict_types=1);
$pageTitle = 'Products';
require_once __DIR__ . '/../../admin/_layout.php';

$search = trim($_GET['q'] ?? '');
$params = [];
$where  = '';
if ($search !== '') {
    $where    = 'WHERE p.name LIKE ?';
    $params[] = "%{$search}%";
}

$products = $pdo->prepare(
    "SELECT p.*, c.name AS category_name
     FROM products p LEFT JOIN categories c ON p.category_id = c.id
     {$where} ORDER BY p.created_at DESC"
);
$products->execute($params);
$products = $products->fetchAll();
?>

<div class="flex items-center justify-between mb-6">
  <div>
    <h2 class="text-lg font-semibold text-stone-800">All Products</h2>
    <p class="text-xs text-stone-400"><?= count($products) ?> product<?= count($products) !== 1 ? 's' : '' ?></p>
  </div>
  <a href="/admin/products/create.php" class="btn btn-rose">+ Add Product</a>
</div>

<!-- Search -->
<form method="GET" class="mb-4 flex gap-3">
  <div class="relative flex-1 max-w-xs">
    <input type="text" name="q" value="<?= h($search) ?>" placeholder="Search products…"
           class="w-full pl-9 pr-3 text-sm" />
    <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
  </div>
  <button type="submit" class="btn btn-outline">Search</button>
  <?php if ($search): ?><a href="list.php" class="btn btn-outline text-stone-400">Clear</a><?php endif; ?>
</form>

<div class="bg-white rounded-2xl shadow-sm overflow-hidden">
  <table class="min-w-full">
    <thead><tr>
      <th class="px-4 py-3 text-left">Image</th>
      <th class="px-4 py-3 text-left">Product</th>
      <th class="px-4 py-3 text-left">Category</th>
      <th class="px-4 py-3 text-left">Price</th>
      <th class="px-4 py-3 text-left">Stock</th>
      <th class="px-4 py-3 text-left">Featured</th>
      <th class="px-4 py-3 text-left">Actions</th>
    </tr></thead>
    <tbody class="divide-y divide-stone-50">
      <?php if (empty($products)): ?>
      <tr><td colspan="7" class="px-6 py-8 text-center text-stone-400">No products found.</td></tr>
      <?php else: foreach ($products as $p): ?>
      <tr class="hover:bg-stone-50/50">
        <td class="px-4 py-3">
          <img src="<?= product_image($p['image_url'] ?? null) ?>"
               class="w-12 h-12 rounded-xl object-cover" alt="<?= h($p['name']) ?>" />
        </td>
        <td class="px-4 py-3 max-w-[180px]">
          <div class="font-medium text-stone-800 text-sm line-clamp-1"><?= h($p['name']) ?></div>
          <div class="text-xs text-stone-400 mt-0.5 font-mono">#<?= $p['id'] ?></div>
        </td>
        <td class="px-4 py-3 text-sm text-stone-500"><?= h($p['category_name'] ?? '—') ?></td>
        <td class="px-4 py-3 text-sm font-semibold text-stone-800">$<?= number_format($p['price'], 2) ?></td>
        <td class="px-4 py-3">
          <span class="badge <?= $p['stock_quantity'] > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
            <?= $p['stock_quantity'] ?>
          </span>
        </td>
        <td class="px-4 py-3 text-stone-400 text-sm"><?= $p['featured'] ? '⭐' : '—' ?></td>
        <td class="px-4 py-3">
          <div class="flex items-center gap-2">
            <a href="/admin/products/edit.php?id=<?= $p['id'] ?>" class="btn btn-outline text-xs py-1 px-3">Edit</a>
            <form action="/actions/product_delete.php" method="POST"
                  onsubmit="return confirm('Delete \'<?= h(addslashes($p['name'])) ?>\'?')">
              <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>" />
              <input type="hidden" name="id" value="<?= $p['id'] ?>" />
              <button type="submit" class="btn btn-danger text-xs py-1 px-3">Delete</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/../../admin/_layout_close.php'; ?>
