<?php
// admin/products/edit.php
declare(strict_types=1);
$pageTitle = 'Edit Product';
require_once __DIR__ . '/../../admin/_layout.php';

$id = isset($_GET['id']) && ctype_digit($_GET['id']) ? (int)$_GET['id'] : null;
if (!$id) { set_flash('error', 'Invalid product ID.'); redirect('/admin/products/list.php'); }

$stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) { set_flash('error', 'Product not found.'); redirect('/admin/products/list.php'); }

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
?>

<div class="max-w-2xl">
  <a href="list.php" class="inline-flex items-center gap-1 text-sm text-stone-400 hover:text-stone-700 mb-5 transition">← Back to Products</a>

  <div class="bg-white rounded-2xl shadow-sm p-7">
    <h2 class="text-base font-semibold text-stone-800 mb-5">Edit: <?= h($product['name']) ?></h2>
    <form action="/actions/product_save.php" method="POST" enctype="multipart/form-data" class="space-y-5">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>" />
      <input type="hidden" name="id" value="<?= $product['id'] ?>" />

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div class="sm:col-span-2">
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Product Name *</label>
          <input type="text" name="name" required value="<?= h($product['name']) ?>" class="w-full" />
        </div>
        <div class="sm:col-span-2">
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Description *</label>
          <textarea name="description" rows="4" required class="w-full resize-none"><?= h($product['description']) ?></textarea>
        </div>
        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Price (USD) *</label>
          <input type="number" name="price" step="0.01" min="0" required value="<?= $product['price'] ?>" class="w-full" />
        </div>
        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Stock Quantity *</label>
          <input type="number" name="stock_quantity" min="0" required value="<?= $product['stock_quantity'] ?>" class="w-full" />
        </div>
        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Category</label>
          <select name="category_id" class="w-full">
            <option value="">— None —</option>
            <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= (int)$product['category_id'] === (int)$cat['id'] ? 'selected' : '' ?>>
              <?= h($cat['name']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="flex items-end gap-3">
          <label class="flex items-center gap-2 cursor-pointer text-sm text-stone-700 font-medium">
            <input type="checkbox" name="featured" value="1" <?= $product['featured'] ? 'checked' : '' ?> class="accent-rose w-4 h-4" />
            Featured product
          </label>
        </div>

        <!-- Current Image -->
        <div class="sm:col-span-2">
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Product Image</label>
          <?php if ($product['image_url']): ?>
          <div class="mb-3 flex items-center gap-4">
            <img src="<?= h($product['image_url']) ?>" alt="Current image"
                 class="w-24 h-24 object-cover rounded-xl border border-stone-100" />
            <div class="text-xs text-stone-400">Current image. Upload a new one to replace it.</div>
          </div>
          <?php endif; ?>
          <div class="border-2 border-dashed border-stone-200 rounded-xl p-5 text-center hover:border-rose transition">
            <input type="file" name="image" id="image-input" accept="image/jpeg,image/png,image/webp"
                   class="hidden" onchange="previewImage(this)" />
            <label for="image-input" class="cursor-pointer">
              <div id="image-preview-wrap" class="text-stone-400 text-sm">
                📷 Click to replace image
                <div class="text-xs text-stone-300 mt-1">JPG, PNG or WEBP · Max 2 MB</div>
              </div>
              <img id="image-preview" src="" alt="" class="hidden mx-auto max-h-48 rounded-xl mt-3" />
            </label>
          </div>
        </div>
      </div>

      <div class="flex items-center gap-3 pt-2">
        <button type="submit" class="btn btn-rose px-6 py-2.5">Update Product</button>
        <a href="list.php" class="btn btn-outline px-6 py-2.5">Cancel</a>
      </div>
    </form>
  </div>
</div>

<script>
function previewImage(input) {
  const wrap = document.getElementById('image-preview-wrap');
  const img  = document.getElementById('image-preview');
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => {
      img.src = e.target.result;
      img.classList.remove('hidden');
      wrap.classList.add('hidden');
    };
    reader.readAsDataURL(input.files[0]);
  }
}
</script>

<?php require_once __DIR__ . '/../../admin/_layout_close.php'; ?>
