<?php
// admin/products/create.php
declare(strict_types=1);
$pageTitle = 'Add Product';
require_once __DIR__ . '/../../admin/_layout.php';

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
?>

<div class="max-w-2xl">
  <a href="list.php" class="inline-flex items-center gap-1 text-sm text-stone-400 hover:text-stone-700 mb-5 transition">← Back to Products</a>

  <div class="bg-white rounded-2xl shadow-sm p-7">
    <h2 class="text-base font-semibold text-stone-800 mb-5">New Product</h2>
    <form action="/actions/product_save.php" method="POST" enctype="multipart/form-data" class="space-y-5">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>" />

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div class="sm:col-span-2">
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Product Name *</label>
          <input type="text" name="name" required class="w-full" />
        </div>
        <div class="sm:col-span-2">
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Description *</label>
          <textarea name="description" rows="4" required class="w-full resize-none"></textarea>
        </div>
        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Price (USD) *</label>
          <input type="number" name="price" step="0.01" min="0" required class="w-full" placeholder="0.00" />
        </div>
        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Stock Quantity *</label>
          <input type="number" name="stock_quantity" min="0" required class="w-full" placeholder="0" />
        </div>
        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Category</label>
          <select name="category_id" class="w-full">
            <option value="">— None —</option>
            <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>"><?= h($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="flex items-end gap-3">
          <label class="flex items-center gap-2 cursor-pointer text-sm text-stone-700 font-medium">
            <input type="checkbox" name="featured" value="1" class="accent-rose w-4 h-4" />
            Featured product
          </label>
        </div>
        <div class="sm:col-span-2">
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Product Image</label>
          <div class="border-2 border-dashed border-stone-200 rounded-xl p-5 text-center hover:border-rose transition">
            <input type="file" name="image" id="image-input" accept="image/jpeg,image/png,image/webp"
                   class="hidden" onchange="previewImage(this)" />
            <label for="image-input" class="cursor-pointer">
              <div id="image-preview-wrap">
                <div class="text-stone-400 text-sm">📷 Click to upload image</div>
                <div class="text-xs text-stone-300 mt-1">JPG, PNG or WEBP · Max 2 MB</div>
              </div>
              <img id="image-preview" src="" alt="" class="hidden mx-auto max-h-48 rounded-xl mt-3" />
            </label>
          </div>
        </div>
      </div>

      <div class="flex items-center gap-3 pt-2">
        <button type="submit" class="btn btn-rose px-6 py-2.5">Save Product</button>
        <a href="list.php" class="btn btn-outline px-6 py-2.5">Cancel</a>
      </div>
    </form>
  </div>
</div>

<script>
function previewImage(input) {
  const wrap = document.getElementById('image-preview-wrap');
  const img  = document.getElementById('image-preview');
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => {
      img.src = e.target.result;
      img.classList.remove('hidden');
      wrap.classList.add('hidden');
    };
    reader.readAsDataURL(input.files[0]);
  }
}
</script>

<?php require_once __DIR__ . '/../../admin/_layout_close.php'; ?>
