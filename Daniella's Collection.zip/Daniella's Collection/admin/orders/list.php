<?php
// admin/orders/list.php
declare(strict_types=1);
$pageTitle = 'Orders';
require_once __DIR__ . '/../../admin/_layout.php';

$statusFilter = $_GET['status'] ?? '';
$params = [];
$where  = '';
$validStatuses = ['pending','processing','shipped','delivered'];
if (in_array($statusFilter, $validStatuses, true)) {
    $where    = 'WHERE status = ?';
    $params[] = $statusFilter;
}

$orders = $pdo->prepare("SELECT * FROM orders {$where} ORDER BY created_at DESC LIMIT 100");
$orders->execute($params);
$orders = $orders->fetchAll();

$statusColors = [
    'pending'    => 'bg-yellow-100 text-yellow-800',
    'processing' => 'bg-blue-100 text-blue-800',
    'shipped'    => 'bg-purple-100 text-purple-800',
    'delivered'  => 'bg-green-100 text-green-800',
];
?>

<div class="flex items-center justify-between mb-6">
  <div>
    <h2 class="text-lg font-semibold text-stone-800">All Orders</h2>
    <p class="text-xs text-stone-400"><?= count($orders) ?> order<?= count($orders) !== 1 ? 's' : '' ?></p>
  </div>
</div>

<!-- Status Filter Tabs -->
<div class="flex flex-wrap gap-2 mb-5">
  <a href="list.php" class="btn <?= $statusFilter === '' ? 'btn-rose' : 'btn-outline' ?> text-xs py-1.5 px-4">All</a>
  <?php foreach ($validStatuses as $s): ?>
  <a href="list.php?status=<?= $s ?>"
     class="btn <?= $statusFilter === $s ? 'btn-rose' : 'btn-outline' ?> text-xs py-1.5 px-4">
    <?= ucfirst($s) ?>
  </a>
  <?php endforeach; ?>
</div>

<div class="bg-white rounded-2xl shadow-sm overflow-hidden">
  <table class="min-w-full">
    <thead><tr>
      <th class="px-6 py-3 text-left">Order</th>
      <th class="px-6 py-3 text-left">Customer</th>
      <th class="px-6 py-3 text-left">Email</th>
      <th class="px-6 py-3 text-left">Total</th>
      <th class="px-6 py-3 text-left">Status</th>
      <th class="px-6 py-3 text-left">Date</th>
      <th class="px-6 py-3 text-left">Actions</th>
    </tr></thead>
    <tbody class="divide-y divide-stone-50">
      <?php if (empty($orders)): ?>
      <tr><td colspan="7" class="px-6 py-8 text-center text-stone-400">No orders found.</td></tr>
      <?php else: foreach ($orders as $order):
        $sc = $statusColors[$order['status']] ?? 'bg-stone-100 text-stone-600';
      ?>
      <tr class="hover:bg-stone-50/50">
        <td class="px-6 py-3 font-mono text-stone-500 text-sm">#<?= $order['id'] ?></td>
        <td class="px-6 py-3 font-medium text-stone-800 text-sm"><?= h($order['customer_name']) ?></td>
        <td class="px-6 py-3 text-stone-500 text-xs"><?= h($order['customer_email']) ?></td>
        <td class="px-6 py-3 font-semibold text-stone-800 text-sm">$<?= number_format($order['total_amount'],2) ?></td>
        <td class="px-6 py-3">
          <!-- Inline status update -->
          <form action="/actions/update_order_status.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>" />
            <input type="hidden" name="order_id" value="<?= $order['id'] ?>" />
            <select name="status" onchange="this.form.submit()"
                    class="text-xs py-1 px-2 rounded-lg border border-stone-200 <?= $sc ?>">
              <?php foreach ($validStatuses as $s): ?>
              <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
          </form>
        </td>
        <td class="px-6 py-3 text-stone-400 text-xs"><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
        <td class="px-6 py-3">
          <a href="/admin/orders/view.php?id=<?= $order['id'] ?>" class="btn btn-outline text-xs py-1 px-3">View</a>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/../../admin/_layout_close.php'; ?>
