<?php
// admin/orders/view.php
declare(strict_types=1);
$pageTitle = 'View Order';
require_once __DIR__ . '/../../admin/_layout.php';

$id = isset($_GET['id']) && ctype_digit($_GET['id']) ? (int)$_GET['id'] : null;
if (!$id) {
    set_flash('error', 'Invalid order ID.');
    redirect('/admin/orders/list.php');
}

// Fetch Order
$stmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order) {
    set_flash('error', 'Order not found.');
    redirect('/admin/orders/list.php');
}

// Fetch Items
$stmtItems = $pdo->prepare(
    'SELECT oi.*, p.name, p.image_url FROM order_items oi
     JOIN products p ON oi.product_id = p.id
     WHERE oi.order_id = ?'
);
$stmtItems->execute([$id]);
$items = $stmtItems->fetchAll();

$validStatuses = ['pending', 'processing', 'shipped', 'delivered'];
?>

<div class="max-w-4xl">
  <div class="flex items-center justify-between mb-5">
    <a href="list.php" class="inline-flex items-center gap-1 text-sm text-stone-400 hover:text-stone-700 transition">
      ← Back to Orders
    </a>
    <div class="flex items-center gap-3">
      <span class="text-sm font-semibold text-stone-500 uppercase tracking-wider">Update Status:</span>
      <form action="/actions/update_order_status.php" method="POST" class="flex gap-2 items-center">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>" />
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>" />
        <select name="status" class="py-1.5 px-3">
          <?php foreach ($validStatuses as $s): ?>
          <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-rose text-xs py-1.5 px-3">Save</button>
      </form>
    </div>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
    <!-- Order Info -->
    <div class="bg-white rounded-2xl shadow-sm p-6 md:col-span-2">
      <h2 class="text-lg font-semibold text-stone-800 border-b border-stone-100 pb-3 mb-4">Order Details</h2>
      <div class="grid grid-cols-2 gap-4 mb-6">
        <div>
          <div class="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-1">Order Number</div>
          <div class="font-mono text-stone-700">#<?= $order['id'] ?></div>
        </div>
        <div>
          <div class="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-1">Date</div>
          <div class="text-stone-700"><?= date('F j, Y, g:i a', strtotime($order['created_at'])) ?></div>
        </div>
        <div>
          <div class="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-1">Total Amount</div>
          <div class="text-rose font-bold text-lg">$<?= number_format($order['total_amount'], 2) ?></div>
        </div>
        <div>
          <div class="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-1">Status</div>
          <?php
            $statusColors = ['pending'=>'bg-yellow-100 text-yellow-800','processing'=>'bg-blue-100 text-blue-800','shipped'=>'bg-purple-100 text-purple-800','delivered'=>'bg-green-100 text-green-800'];
            $sc = $statusColors[$order['status']] ?? 'bg-stone-100 text-stone-600';
          ?>
          <span class="badge <?= $sc ?> text-sm px-2 py-1"><?= ucfirst($order['status']) ?></span>
        </div>
      </div>
    </div>

    <!-- Customer Info -->
    <div class="bg-white rounded-2xl shadow-sm p-6">
      <h2 class="text-base font-semibold text-stone-800 border-b border-stone-100 pb-3 mb-4">Customer</h2>
      <div class="space-y-3">
        <div>
          <div class="text-xs text-stone-400">Name</div>
          <div class="font-medium text-stone-800"><?= h($order['customer_name']) ?></div>
        </div>
        <div>
          <div class="text-xs text-stone-400">Email</div>
          <a href="mailto:<?= h($order['customer_email']) ?>" class="text-rose hover:underline break-all"><?= h($order['customer_email']) ?></a>
        </div>
        <div>
          <div class="text-xs text-stone-400">Phone</div>
          <div class="text-stone-800"><?= h($order['customer_phone'] ?? '—') ?></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Items -->
  <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
    <div class="px-6 py-4 border-b border-stone-100">
      <h2 class="text-base font-semibold text-stone-800">Purchased Items</h2>
    </div>
    <table class="min-w-full">
      <thead><tr>
        <th class="px-6 py-3 text-left">Product</th>
        <th class="px-6 py-3 text-right">Price</th>
        <th class="px-6 py-3 text-center">Qty</th>
        <th class="px-6 py-3 text-right">Line Total</th>
      </tr></thead>
      <tbody class="divide-y divide-stone-50">
        <?php foreach ($items as $item): ?>
        <tr>
          <td class="px-6 py-4 flex items-center gap-4">
            <img src="<?= product_image($item['image_url'] ?? null) ?>"
                 class="w-12 h-12 rounded-xl object-cover" alt="<?= h($item['name']) ?>" />
            <div>
              <div class="font-medium text-stone-800 text-sm"><?= h($item['name']) ?></div>
              <div class="text-xs text-stone-400 font-mono mt-0.5">Product ID: <?= $item['product_id'] ?></div>
            </div>
          </td>
          <td class="px-6 py-4 text-right text-sm text-stone-600">$<?= number_format($item['price_at_purchase'], 2) ?></td>
          <td class="px-6 py-4 text-center text-sm font-semibold text-stone-800"><?= $item['quantity'] ?></td>
          <td class="px-6 py-4 text-right text-sm font-bold text-stone-800">$<?= number_format($item['price_at_purchase'] * $item['quantity'], 2) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../../admin/_layout_close.php'; ?>
