<?php
// admin/_layout.php — shared admin shell
// Expects: $pageTitle (string)
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';
require_admin();

$adminUser  = $_SESSION['admin_username'] ?? 'Admin';
$flash      = get_flash();
if (!isset($pageTitle)) $pageTitle = 'Admin – Daniella\'s Collection';

// Stats for dashboard (loaded lazily)
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= h($pageTitle) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    body { font-family:'Inter',sans-serif; background:#f5f3f0; }
    .sidebar-link { display:flex; align-items:center; gap:.6rem; padding:.6rem 1rem; border-radius:.75rem; font-size:.88rem; font-weight:500; color:#6b7280; transition:all .2s; }
    .sidebar-link:hover, .sidebar-link.active { background:#c2847a20; color:#c2847a; }
    .btn { border-radius:.75rem; padding:.55rem 1.2rem; font-weight:600; font-size:.85rem; transition:all .2s; display:inline-flex; align-items:center; gap:.4rem; }
    .btn-rose { background:#c2847a; color:#fff; }
    .btn-rose:hover { background:#a0665d; }
    .btn-outline { border:1.5px solid #d1d5db; color:#374151; }
    .btn-outline:hover { border-color:#c2847a; color:#c2847a; }
    .btn-danger { background:#fee2e2; color:#991b1b; }
    .btn-danger:hover { background:#fca5a5; }
    table thead th { background:#f5f3f0; color:#9ca3af; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em; }
    .badge { display:inline-flex; align-items:center; border-radius:.4rem; padding:.15rem .5rem; font-size:.72rem; font-weight:600; }
    input[type=text], input[type=number], input[type=email], input[type=password], textarea, select {
      border:1.5px solid #e5e7eb; border-radius:.75rem; padding:.55rem .85rem; font-size:.875rem; transition:border-color .2s;
    }
    input:focus, textarea:focus, select:focus { outline:none; border-color:#c2847a; box-shadow:0 0 0 3px rgba(194,132,122,0.15); }
  </style>
</head>
<body class="flex min-h-screen">

<!-- Sidebar -->
<aside class="w-56 shrink-0 bg-white border-r border-stone-100 flex flex-col sticky top-0 h-screen">
  <div class="px-5 py-5 border-b border-stone-100">
    <span class="font-bold text-stone-800 text-sm">Daniella's Collection</span>
    <div class="text-xs text-stone-400 mt-0.5">Admin Panel</div>
  </div>
  <nav class="flex-1 px-3 py-4 space-y-1">
    <a href="/admin/dashboard.php"      class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
      📊 Dashboard
    </a>
    <a href="/admin/products/list.php"  class="sidebar-link <?= strpos($_SERVER['PHP_SELF'],'products') !== false ? 'active' : '' ?>">
      👗 Products
    </a>
    <a href="/admin/orders/list.php"    class="sidebar-link <?= strpos($_SERVER['PHP_SELF'],'orders') !== false ? 'active' : '' ?>">
      📦 Orders
    </a>
    <a href="/"                         class="sidebar-link">🛍 View Store</a>
  </nav>
  <div class="px-3 py-4 border-t border-stone-100">
    <div class="text-xs text-stone-400 px-2 mb-2">Signed in as <strong class="text-stone-600"><?= h($adminUser) ?></strong></div>
    <a href="/actions/logout.php" class="sidebar-link text-red-400 hover:text-red-600 hover:bg-red-50">🚪 Sign Out</a>
  </div>
</aside>

<!-- Main Content Area -->
<div class="flex-1 flex flex-col min-w-0">
  <!-- Top bar -->
  <header class="bg-white border-b border-stone-100 px-8 py-3 flex items-center justify-between sticky top-0 z-10">
    <h1 class="text-base font-semibold text-stone-800"><?= h($pageTitle) ?></h1>
    <div class="text-xs text-stone-400"><?= date('l, F j, Y') ?></div>
  </header>

  <main class="flex-1 px-8 py-6">
    <?php if ($flash): ?>
    <div class="mb-5 rounded-xl px-4 py-3 text-sm font-medium flex items-center gap-2
      <?= $flash['type'] === 'success'
          ? 'bg-green-50 text-green-800 border border-green-200'
          : 'bg-red-50 text-red-800 border border-red-200' ?>">
      <?= $flash['type'] === 'success' ? '✓' : '✕' ?>
      <?= h($flash['message']) ?>
    </div>
    <?php endif; ?>
