<?php
// admin/_layout_close.php — closes admin layout
?>
  </main>
</div><!-- end flex-1 -->
</body>
</html>
