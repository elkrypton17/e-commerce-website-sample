<?php
// admin/login.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

if (is_admin()) redirect('/admin/dashboard.php');

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login – Daniella's Collection</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    body { font-family:'Inter',sans-serif; }
    .btn-primary { background:#c2847a; color:#fff; border-radius:.75rem; padding:.65rem 1.5rem; font-weight:600; font-size:.95rem; transition:background .2s; }
    .btn-primary:hover { background:#a0665d; }
    input:focus { outline:none; border-color:#c2847a; box-shadow:0 0 0 3px rgba(194,132,122,0.2); }
  </style>
</head>
<body class="min-h-screen bg-gradient-to-br from-stone-100 to-rose-50 flex items-center justify-center px-4">

  <div class="w-full max-w-sm">
    <!-- Brand -->
    <div class="text-center mb-8">
      <h1 class="text-2xl font-bold text-stone-800">Daniella's Collection</h1>
      <p class="text-stone-500 text-sm mt-1">Admin Dashboard</p>
    </div>

    <div class="bg-white rounded-2xl shadow-lg p-8">
      <h2 class="text-lg font-semibold text-stone-800 mb-5">Sign in to continue</h2>

      <?php if ($flash): ?>
      <div class="mb-4 rounded-xl px-4 py-3 text-sm font-medium
        <?= $flash['type'] === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800' ?>">
        <?= h($flash['message']) ?>
      </div>
      <?php endif; ?>

      <form action="/actions/login_process.php" method="POST" class="space-y-4">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>" />

        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Username</label>
          <input type="text" name="username" required autocomplete="username"
                 class="w-full border border-stone-200 rounded-xl px-4 py-2.5 text-sm transition" />
        </div>

        <div>
          <label class="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">Password</label>
          <input type="password" name="password" required autocomplete="current-password"
                 class="w-full border border-stone-200 rounded-xl px-4 py-2.5 text-sm transition" />
        </div>

        <button type="submit" class="btn-primary w-full mt-2">Sign In →</button>
      </form>
    </div>

    <a href="/" class="block text-center text-stone-400 text-xs mt-5 hover:text-stone-600 transition">
      ← Back to storefront
    </a>
  </div>

</body>
</html>
