<?php
declare(strict_types=1);

function h(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function money(float|string $amount): string {
    return '$' . number_format((float)$amount, 2);
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit();
}

function slug(string $text): string {
    $text = mb_strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

function product_image(string|null $imageUrl): string {
    if ($imageUrl && file_exists(__DIR__ . '/../public' . $imageUrl)) {
        return h($imageUrl);
    }
    // Return a placeholder SVG data URI
    return "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect fill='%23f1ede8' width='400' height='400'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-family='Inter,sans-serif' font-size='18' fill='%23b8a99a'%3ENo Image%3C/text%3E%3C/svg%3E";
}
