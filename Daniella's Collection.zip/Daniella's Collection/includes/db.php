<?php
declare(strict_types=1);

// ─── Load .env manually (no composer needed) ───────────────────────
$envFile = dirname(__DIR__) . '/.env';
if (file_exists($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        [$key, $val] = explode('=', $line, 2) + [1 => ''];
        $_ENV[trim($key)] = trim($val);
        putenv(trim($key) . '=' . trim($val));
    }
}

$host    = $_ENV['DB_HOST'] ?? 'localhost';
$dbName  = $_ENV['DB_NAME'] ?? 'daniellas_collection';
$dbUser  = $_ENV['DB_USER'] ?? 'root';
$dbPass  = $_ENV['DB_PASS'] ?? '';
$charset = 'utf8mb4';

$dsn = "mysql:host={$host};dbname={$dbName};charset={$charset}";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
} catch (PDOException $e) {
    http_response_code(503);
    error_log('DB connection failed: ' . $e->getMessage());
    die(json_encode(['error' => 'Service unavailable. Please try again later.']));
}
